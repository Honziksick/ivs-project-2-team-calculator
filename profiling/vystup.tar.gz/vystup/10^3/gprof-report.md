# Zpráva z Gprof
## Informace o systému
**honziksick@CAREN**
- **OS:** Ubuntu 22.04.4 LTS on Windows 10 x86_64
- **Kernel:** 5.15.146.1-microsoft-standard-WSL2
- **Uptime:** 4 hours, 12 mins
- **Packages:** 1983 (dpkg), 10 (snap)
- **Shell:** bash 5.1.16
- **Terminal:** Windows Terminal
- **CPU:** AMD Ryzen 5 2600 (12) @ 3.400GHz
- **GPU:** 6fc0:00:00.0 Microsoft Corporation Device 008e
- **Memory:** 1762MiB / 7921MiB

## Flat profile
### Každý vzorek je počítán jako 0.01 sekundy.
| Time [%] | Cumulative [s] | Self [s] | Calls | Self [ms/call] | Total [ms/call] | Name |
|:---:|:---:|:---:|:---:|:---:|:---:|---|
| 5.88 | 0.12 | 0.01 | 42105 | 0.00 | 0.00 | catMath::parse() |
| 0.00 | 0.17 | 0.00 | 1604505 | 0.00 | 0.00 | catMath::isOperator() |
| 0.00 | 0.17 | 0.00 | 201768 | 0.00 | 0.00 | catMath::priority() |
| 0.00 | 0.17 | 0.00 | 189357 | 0.00 | 0.00 | catMath::absVal() |
| 0.00 | 0.17 | 0.00 | 101745 | 0.00 | 0.00 | catMath::evaluateOperation() |
| 0.00 | 0.17 | 0.00 | 101724 | 0.00 | 0.00 | catMath::doubleToString() |
| 0.00 | 0.17 | 0.00 | 42105 | 0.00 | 0.00 | catMath::formatInput() |
| 0.00 | 0.17 | 0.00 | 42105 | 0.00 | 0.00 | catMath::pairParenthesis() |
| 0.00 | 0.17 | 0.00 | 42105 | 0.00 | 0.00 | catMath::removeMultSpaces() |
| 0.00 | 0.17 | 0.00 | 42105 | 0.00 | 0.00 | catMath::postfix() |
| 0.00 | 0.17 | 0.00 | 42105 | 0.00 | 0.00 | catMath::evaluate() |
| 0.00 | 0.17 | 0.00 | 42105 | 0.00 | 0.00 | catMath::calculate() |
| 0.00 | 0.17 | 0.00 | 42000 | 0.00 | 0.00 | catMath::evalAdd() |
| 0.00 | 0.17 | 0.00 | 38577 | 0.00 | 0.00 | catMath::evalNeg() |
| 0.00 | 0.17 | 0.00 | 29442 | 0.00 | 0.00 | catMath::power() |
| 0.00 | 0.17 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalDiv() |
| 0.00 | 0.17 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalMul() |
| 0.00 | 0.17 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalSub() |
| 0.00 | 0.17 | 0.00 | 21 | 0.00 | 0.00 | catMath::root() |
| 0.00 | 0.17 | 0.00 | 21 | 0.00 | 7.60 | catStddev::readDataFromStdin() |
| 0.00 | 0.17 | 0.00 | 21 | 0.00 | 7.86 | catStddev::standardDeviation() |
| 0.00 | 0.17 | 0.00 | 21 | 0.00 | 7.60 | catStddev::readData() |


<br>

- `%`:
  - **=** Procento celkové doby běhu programu využité touto funkcí.
- `Cumulative seconds`:
  - **=** Běžný součet sekund přiřazených této funkci a těm, které jsou uvedeny nad ní.
- `Self seconds`:
  - **=** Počet sekund přiřazených pouze této funkci.
  - Toto je hlavní kritérium pro toto seřazení.
- `Calls`:
  - **=** Počet volání této funkce, pokud je tato funkce profilována, jinak prázdné.
- `Self ms/call`:
  - **=** Průměrný počet milisekund strávených v této funkci na volání, pokud je tato funkce profilována, jinak prázdné.
- `Total ms/call`:
  - **=** Průměrný počet milisekund strávených v této funkci a jejích potomcích na volání, pokud je tato funkce profilována, jinak prázdné.
- `Name`:
  - **= Název funkce**
  - Toto je vedlejší kritérium pro toto seřazení.
  - Index ukazuje umístění funkce v seznamu *gprof*.
  - Pokud je index v závorce, ukazuje, kde by se objevil v seznamu *gprof*, pokud by byl vytištěn.

<br>

# Graf volání (call graph)

| Index | Time [%] | Self | Children | Called | Name |
|:-----:|:--------:|:----:|:--------:|:------:|------|
| [1] | 97.1 | 0.00 | 0.16 | | main [1] |
| | | 0.00 | 0.16 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.16 | 21/21 | main |
| [2] | 97.1 | 0.00 | 0.16 | 21 | catStddev::standardDeviation() |
| | | 0.00 | 0.16 | 21/21 | catStddev::readDataFromStdin() |
| | | 0.00 | 0.00 | 105/42105 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.16 | 21/21 | catStddev::standardDeviation() |
| [3] | 93.9 | 0.00 | 0.16 | 21 | catStddev::readDataFromStdin() |
| | | 0.00 | 0.16 | 21/21 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.16 | 21/21 | catStddev::readDataFromStdin() |
| [4] | 93.9 | 0.00 | 0.16 | 21 | catStddev::readData() |
| | | 0.00 | 0.15 | 42000/42105 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/42105 | catStddev::standardDeviation() |
| | | 0.00 | 0.15 | 42000/42105 | catStddev::readData() |
| [5] | 87.6 | 0.00 | 0.15 | 42105 | catMath::calculate() |
| | | 0.00 | 0.06 | 42105/42105 | catMath::evaluate() |
| | | 0.01 | 0.02 | 42105/42105 | catMath::parse() |
| | | 0.00 | 0.03 | 42105/42105 | catMath::postfix() |
| | | 0.00 | 0.01 | 42105/42105 | catMath::formatInput() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.01 | 105273/871521 | catMath::parse() |
| | | 0.00 | 0.03 | 350910/871521 | catMath::postfix() |
| | | 0.00 | 0.03 | 415338/871521 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.06 | 42105/42105 | catMath::calculate() |
| [8] | 33.4 | 0.00 | 0.06 | 42105 | catMath::evaluate() |
| | | 0.00 | 0.01 | 101745/101745 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 211890/1604505 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 0.01 | 0.02 | 42105/42105 | catMath::calculate() |
| [9] | 20.4 | 0.01 | 0.02 | 42105 | catMath::parse() |
| | | 0.00 | 0.00 | 1392615/1604505 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.03 | 42105/42105 | catMath::calculate() |
| [10] | 19.5 | 0.00 | 0.03 | 42105 | catMath::postfix() |
| | | 0.00 | 0.00 | 201768/201768 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.02 | 84210/84210 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.01 | 186039/186039 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.01 | 101745/101745 | catMath::evaluate() |
| [20] | 7.2 | 0.00 | 0.01 | 101745 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 42000/42000 | catMath::evalAdd() |
| | | 0.00 | 0.00 | 38577/38577 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 21042/101724 | catMath::doubleToString() |
| | | 0.00 | 0.00 | 21021/29442 | catMath::power() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 21/21 | catMath::root() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/21105 | catStddev::standardDeviation() |
| | | 0.01 | 0.00 | 21000/21105 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21042/4280094 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 81207/4280094 | catMath::calculate() |
| | | 0.00 | 0.00 | 1392615/4280094 | catMath::parse() |
| | | 0.00 | 0.00 | 1392615/4280094 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 1392615/4280094 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.01 | 21042/21042 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/1592073 | catMath::postfix() |
| | | 0.00 | 0.00 | 101745/1592073 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.01 | 101745/101745 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 185955/645141 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 273147/645141 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.01 | 42105/42105 | catMath::calculate() |
| [39] | 3.8 | 0.00 | 0.01 | 42105 | catMath::formatInput() |
| | | 0.00 | 0.00 | 42105/42105 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 42105/42105 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/989037 | catMath::postfix() |
| | | 0.00 | 0.00 | 101745/989037 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.01 | 0.00 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/42105 | catMath::formatInput() |
| [49] | 1.9 | 0.00 | 0.00 | 42105 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/42105 | catMath::formatInput() |
| [50] | 1.9 | 0.00 | 0.00 | 42105 | catMath::removeMultSpaces() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/354375 | catMath::postfix() |
| | | 0.00 | 0.00 | 101745/354375 | catMath::evaluate() |
| | | 0.00 | 0.00 | 168420/354375 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 252/105252 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 105000/105252 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/42105 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/42105 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/63 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42084/4427451 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 81207/4427451 | catMath::calculate() |
| | | 0.00 | 0.00 | 1434720/4427451 | catMath::parse() |
| | | 0.00 | 0.00 | 1434720/4427451 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 1434720/4427451 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21042/4237989 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 39102/4237989 | catMath::calculate() |
| | | 0.00 | 0.00 | 1392615/4237989 | catMath::parse() |
| | | 0.00 | 0.00 | 1392615/4237989 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 1392615/4237989 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63168/3859254 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 245595/3859254 | catMath::postfix() |
| | | 0.00 | 0.00 | 457443/3859254 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/2674812 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 84210/2674812 | catMath::formatInput() |
| | | 0.00 | 0.00 | 84210/2674812 | catMath::calculate() |
| | | 0.00 | 0.00 | 122829/2674812 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 457443/2674812 | catMath::evaluate() |
| | | 0.00 | 0.00 | 493080/2674812 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/1662402 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 329931/1662402 | catMath::postfix() |
| | | 0.00 | 0.00 | 1261911/1662402 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 211890/1604505 | catMath::evaluate() |
| | | 0.00 | 0.00 | 1392615/1604505 | catMath::parse() |
| [92] | 0.0 | 0.00 | 0.00 | 1604505 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 291312/1558809 | catMath::postfix() |
| | | 0.00 | 0.00 | 415338/1558809 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1354038/1354122 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 333417/1117158 | catMath::postfix() |
| | | 0.00 | 0.00 | 517083/1117158 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 291312/871563 | catMath::postfix() |
| | | 0.00 | 0.00 | 415338/871563 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 143892/308805 | catMath::postfix() |
| | | 0.00 | 0.00 | 164913/308805 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42105/228060 | catMath::parse() |
| | | 0.00 | 0.00 | 84210/228060 | catMath::postfix() |
| | | 0.00 | 0.00 | 101745/228060 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 201768/201768 | catMath::postfix() |
| [136] | 0.0 | 0.00 | 0.00 | 201768 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/189357 | catMath::evalMul() |
| | | 0.00 | 0.00 | 12663/189357 | catMath::root() |
| | | 0.00 | 0.00 | 176652/189357 | catMath::power() |
| [137] | 0.0 | 0.00 | 0.00 | 189357 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/164829 | catMath::evalSub() |
| | | 0.00 | 0.00 | 84/164829 | catMath::evalMul() |
| | | 0.00 | 0.00 | 84/164829 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 21000/164829 | catStddev::readData() |
| | | 0.00 | 0.00 | 21042/164829 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 38577/164829 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 84000/164829 | catMath::evalAdd() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/101724 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/101724 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/101724 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 21042/101724 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 38577/101724 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 42000/101724 | catMath::evalAdd() |
| [149] | 0.0 | 0.00 | 0.00 | 101724 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 101724/101724 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/80892 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 80682/80892 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 70518/70518 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 126/63126 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 63000/63126 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/58905 | catMath::evalMul() |
| | | 0.00 | 0.00 | 58884/58905 | catMath::power() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42000/42000 | catMath::evaluateOperation() |
| [175] | 0.0 | 0.00 | 0.00 | 42000 | catMath::evalAdd() |
| | | 0.00 | 0.00 | 42000/101724 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 38577/38577 | catMath::evaluateOperation() |
| [176] | 0.0 | 0.00 | 0.00 | 38577 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 38577/101724 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 8421/29442 | catMath::root() |
| | | 0.00 | 0.00 | 21021/29442 | catMath::evaluateOperation() |
| [177] | 0.0 | 0.00 | 0.00 | 29442 | catMath::power() |
| | | 0.00 | 0.00 | 176652/189357 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/84 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/84 | catMath::evalDiv() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/63 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [189] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 42/101724 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [190] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/101724 | catMath::doubleToString() |
| | | 0.00 | 0.00 | 42/189357 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [191] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalSub() |
| | | 0.00 | 0.00 | 21/101724 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | _GLOBAL__sub_I__ZN9catStddev4helpEv() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catMath::evaluateOperation() |
| [194] | 0.0 | 0.00 | 0.00 | 21 | catMath::root() |
| | | 0.00 | 0.00 | 12663/189357 | catMath::absVal() |
| | | 0.00 | 0.00 | 8421/29442 | catMath::power() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catMath::evalSub() |
| | | | | | |
| | | | | | |
<br>

Tato tabulka popisuje strom volání programu a byla seřazena podle celkového času stráveného v každé funkci a jejích potomcích.

Každý záznam v této tabulce se skládá z několika řádků. Řádek s indexovým číslem na levém okraji uvádí aktuální funkci. Řádky nad ním uvádějí funkce, které tuto funkci volaly, a řádky pod ním uvádějí funkce, které tato funkce volala. Tento řádek uvádí:

- `index`
  - Jedinečné číslo přidělené každému prvku tabulky.
  - Indexová čísla jsou seřazena numericky.
  - Indexové číslo je vytisknuto vedle každého názvu funkce, aby bylo snazší zjistit, kde je funkce v tabulce.
- `time [%]`
  - Toto je procento z *celkového* času, které bylo stráveno v této funkci a jejích potomcích.

  - Vzhledem k různým hlediskům, vyloučenými funkcemi atd. se tyto čísla NESEČTOU na 100%.
- `self`
  - Toto je celkové množství času stráveného v této funkci.
- `children`
  - Toto je celkové množství času, které do této funkce přenesly její potomci.
- `called`
  - Toto je počet volání funkce.
  - Pokud funkce volala sama sebe rekurzivně, číslo zahrnuje pouze nerekurzivní volání a je následováno `+` a počtem rekurzivních volání.
- `name` - Název aktuální funkce.
  - Indexové číslo je vytisknuto za ním.
  - Pokud je funkce členem cyklu, číslo cyklu je vytisknuto mezi názvem funkce a indexovým číslem.

<br>


**Pro rodiče funkce mají pole následující významy:**

- `self`
  - Toto je množství času, které bylo přímo přeneseno z funkce do tohoto rodiče.
- `children`
  - Toto je množství času, které bylo přeneseno z potomků funkce do tohoto rodiče.
- `called`
  - Toto je počet volání, které tento rodič provedl funkci `/` celkový počet volání funkce.
  - Rekurzivní volání funkce nejsou zahrnuta v čísle za `/`.
- `name` - Toto je název rodiče.
  - Indexové číslo rodiče je vytisknuto za ním.
  - Pokud je rodič členem cyklu, číslo cyklu je vytisknuto mezi názvem a indexovým číslem.
- ***Pokud nelze určit rodiče funkce, pole jsou prázdná.***

<br>


**Pro potomky funkce mají pole následující významy:**

- `self`
  - Toto je množství času, které bylo přímo přeneseno z potomka do funkce.
- `children`
  - Toto je množství času, které bylo přeneseno z potomků potomka do funkce.
- `called`
  - Toto je počet volání, které funkce provedla tomuto potomku `/` celkový počet volání potomka.
  - Rekurzivní volání potomkem nejsou uvedena v čísle za `/`.
- `name`
  - Toto je název potomka.
  - Indexové číslo potomka je vytisknuto za ním.
  - Pokud je potomek členem cyklu, číslo cyklu je vytisknuto mezi názvem a indexovým číslem.

<br>


Pokud jsou v grafu volání nějaké cykly (kruhy), existuje záznam pro celý cyklus. Tento záznam ukazuje, kdo volal cyklus (jako rodiče) a členy cyklu (jako potomky). Záznam `+` rekurzivních volání ukazuje počet volání funkcí, které byly interní pro cyklus, a záznam volání pro každého člena ukazuje, kolikrát byl volán od ostatních členů cyklu.

## Indexy funkcí

-    **[2]** ` catStddev::standardDeviation()`
-    **[3]** ` catStddev::readDataFromStdin()`
-    **[4]** ` catStddev::readData()`
-    **[5]** ` catMath::calculate()`
-    **[8]** ` catMath::evaluate()`
-    **[9]** ` catMath::parse()`
-   **[10]** ` catMath::postfix()`
-   **[20]** ` catMath::evaluateOperation()`
-   **[39]** ` catMath::formatInput()`
-   **[49]** ` catMath::pairParenthesis()`
-   **[50]** ` catMath::removeMultSpaces()`
-   **[92]** ` catMath::isOperator()`
-  **[136]** ` catMath::priority()`
-  **[137]** ` catMath::absVal()`
-  **[149]** ` catMath::doubleToString()`
-  **[175]** ` catMath::evalAdd()`
-  **[176]** ` catMath::evalNeg()`
-  **[177]** ` catMath::power()`
-  **[189]** ` catMath::evalDiv()`
-  **[190]** ` catMath::evalMul()`
-  **[191]** ` catMath::evalSub()`
-  **[194]** ` catMath::root()`
