# Protokol z profilování

### Průběh a výsledky profilování
- Všechny podstatné informace jsou obsaženy v souboru `profiling/zprava.pdf`.

### Informace k profilovacím datům
- K profilování byly využity soubory s daty pro program `stddev` z adresáře
`src/tests/stddev_test_files.tar.gz`, které z kapacitních důvodů nejsou přímo
duplicitně vloženy ve složkách jednotlivých profilovacích případů.
  - **profilování $ 10^1 $ vzorků:** soubor `10_nums.txt`
  - **profilování $ 10^3 $ vzorků:** soubor `1k_nums_1.txt`
  - **profilování $ 10^6 $ vzorků:** soubor `1M_nums.txt`