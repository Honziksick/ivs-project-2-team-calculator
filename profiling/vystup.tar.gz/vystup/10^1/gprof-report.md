# Zpráva z Gprof
## Informace o systému
**honziksick@CAREN**
- **OS:** Ubuntu 22.04.4 LTS on Windows 10 x86_64
- **Kernel:** 5.15.146.1-microsoft-standard-WSL2
- **Uptime:** 4 hours, 9 mins
- **Packages:** 1979 (dpkg), 10 (snap)
- **Shell:** bash 5.1.16
- **Terminal:** Windows Terminal
- **CPU:** AMD Ryzen 5 2600 (12) @ 3.400GHz
- **GPU:** 6fc0:00:00.0 Microsoft Corporation Device 008e
- **Memory:** 1751MiB / 7921MiB

## Flat profile
### Každý vzorek je počítán jako 0.01 sekundy.
| Time [%] | Cumulative [s] | Self [s] | Calls | Self [ms/call] | Total [ms/call] | Name |
|:---:|:---:|:---:|:---:|:---:|:---:|---|
| 0.00 | 0.00 | 0.00 | 64617 | 0.00 | 0.00 | catMath::absVal() |
| 0.00 | 0.00 | 0.00 | 19362 | 0.00 | 0.00 | catMath::isOperator() |
| 0.00 | 0.00 | 0.00 | 8652 | 0.00 | 0.00 | catMath::power() |
| 0.00 | 0.00 | 0.00 | 1176 | 0.00 | 0.00 | catMath::priority() |
| 0.00 | 0.00 | 0.00 | 903 | 0.00 | 0.00 | catMath::evaluateOperation() |
| 0.00 | 0.00 | 0.00 | 882 | 0.00 | 0.00 | catMath::doubleToString() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::formatInput() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::pairParenthesis() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::removeMultSpaces() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::parse() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::postfix() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::evaluate() |
| 0.00 | 0.00 | 0.00 | 525 | 0.00 | 0.00 | catMath::calculate() |
| 0.00 | 0.00 | 0.00 | 420 | 0.00 | 0.00 | catMath::evalAdd() |
| 0.00 | 0.00 | 0.00 | 105 | 0.00 | 0.00 | catMath::evalNeg() |
| 0.00 | 0.00 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalDiv() |
| 0.00 | 0.00 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalMul() |
| 0.00 | 0.00 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalSub() |
| 0.00 | 0.00 | 0.00 | 21 | 0.00 | 0.00 | catMath::root() |
| 0.00 | 0.00 | 0.00 | 21 | 0.00 | 0.00 | catStddev::readDataFromStdin() |
| 0.00 | 0.00 | 0.00 | 21 | 0.00 | 0.00 | catStddev::standardDeviation() |
| 0.00 | 0.00 | 0.00 | 21 | 0.00 | 0.00 | catStddev::readData() |


<br>

- `%`:
  - **=** Procento celkové doby běhu programu využité touto funkcí.
- `Cumulative seconds`:
  - **=** Běžný součet sekund přiřazených této funkci a těm, které jsou uvedeny nad ní.
- `Self seconds`:
  - **=** Počet sekund přiřazených pouze této funkci.
  - Toto je hlavní kritérium pro toto seřazení.
- `Calls`:
  - **=** Počet volání této funkce, pokud je tato funkce profilována, jinak prázdné.
- `Self ms/call`:
  - **=** Průměrný počet milisekund strávených v této funkci na volání, pokud je tato funkce profilována, jinak prázdné.
- `Total ms/call`:
  - **=** Průměrný počet milisekund strávených v této funkci a jejích potomcích na volání, pokud je tato funkce profilována, jinak prázdné.
- `Name`:
  - **= Název funkce**
  - Toto je vedlejší kritérium pro toto seřazení.
  - Index ukazuje umístění funkce v seznamu *gprof*.
  - Pokud je index v závorce, ukazuje, kde by se objevil v seznamu *gprof*, pokud by byl vytištěn.

<br>

# Graf volání (call graph)

| Index | Time [%] | Self | Children | Called | Name |
|:-----:|:--------:|:----:|:--------:|:------:|------|
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/64617 | catMath::evalMul() |
| | | 0.00 | 0.00 | 12663/64617 | catMath::root() |
| | | 0.00 | 0.00 | 51912/64617 | catMath::power() |
| [9] | 0.0 | 0.00 | 0.00 | 64617 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 504/55818 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 819/55818 | catMath::calculate() |
| | | 0.00 | 0.00 | 18165/55818 | catMath::parse() |
| | | 0.00 | 0.00 | 18165/55818 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 18165/55818 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 252/53991 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 819/53991 | catMath::calculate() |
| | | 0.00 | 0.00 | 17640/53991 | catMath::parse() |
| | | 0.00 | 0.00 | 17640/53991 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 17640/53991 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 252/53466 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 294/53466 | catMath::calculate() |
| | | 0.00 | 0.00 | 17640/53466 | catMath::parse() |
| | | 0.00 | 0.00 | 17640/53466 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 17640/53466 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 798/39144 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 2331/39144 | catMath::postfix() |
| | | 0.00 | 0.00 | 4011/39144 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/26754 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 1050/26754 | catMath::formatInput() |
| | | 0.00 | 0.00 | 1050/26754 | catMath::calculate() |
| | | 0.00 | 0.00 | 1197/26754 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 4011/26754 | catMath::evaluate() |
| | | 0.00 | 0.00 | 4536/26754 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1722/19362 | catMath::evaluate() |
| | | 0.00 | 0.00 | 17640/19362 | catMath::parse() |
| [28] | 0.0 | 0.00 | 0.00 | 19362 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 17535/17619 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/17325 | catMath::evalMul() |
| | | 0.00 | 0.00 | 17304/17325 | catMath::power() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/15834 | catMath::postfix() |
| | | 0.00 | 0.00 | 903/15834 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 3360/15288 | catMath::postfix() |
| | | 0.00 | 0.00 | 3486/15288 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/11298 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 3507/11298 | catMath::postfix() |
| | | 0.00 | 0.00 | 7014/11298 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 3885/10878 | catMath::postfix() |
| | | 0.00 | 0.00 | 4389/10878 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/10143 | catMath::postfix() |
| | | 0.00 | 0.00 | 903/10143 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 231/8652 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 8421/8652 | catMath::root() |
| [55] | 0.0 | 0.00 | 0.00 | 8652 | catMath::power() |
| | | 0.00 | 0.00 | 51912/64617 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 3360/8547 | catMath::postfix() |
| | | 0.00 | 0.00 | 3486/8547 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1323/8505 | catMath::parse() |
| | | 0.00 | 0.00 | 3486/8505 | catMath::evaluate() |
| | | 0.00 | 0.00 | 3696/8505 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1953/6216 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 2226/6216 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/4053 | catMath::postfix() |
| | | 0.00 | 0.00 | 903/4053 | catMath::evaluate() |
| | | 0.00 | 0.00 | 2100/4053 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1470/3171 | catMath::postfix() |
| | | 0.00 | 0.00 | 1701/3171 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/2478 | catMath::parse() |
| | | 0.00 | 0.00 | 903/2478 | catMath::evaluate() |
| | | 0.00 | 0.00 | 1050/2478 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 2037/2037 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/1617 | catMath::evalSub() |
| | | 0.00 | 0.00 | 84/1617 | catMath::evalMul() |
| | | 0.00 | 0.00 | 84/1617 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 105/1617 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 210/1617 | catStddev::readData() |
| | | 0.00 | 0.00 | 252/1617 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 840/1617 | catMath::evalAdd() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 252/1302 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 1050/1302 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1176/1176 | catMath::postfix() |
| [110] | 0.0 | 0.00 | 0.00 | 1176 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 1050/1050 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 903/903 | catMath::evaluate() |
| [120] | 0.0 | 0.00 | 0.00 | 903 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 420/420 | catMath::evalAdd() |
| | | 0.00 | 0.00 | 252/882 | catMath::doubleToString() |
| | | 0.00 | 0.00 | 231/8652 | catMath::power() |
| | | 0.00 | 0.00 | 105/105 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 21/21 | catMath::root() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 903/903 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/882 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/882 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/882 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 105/882 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 252/882 | catMath::evaluateOperation() |
| | | 0.00 | 0.00 | 420/882 | catMath::evalAdd() |
| [134] | 0.0 | 0.00 | 0.00 | 882 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 882/882 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/840 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 630/840 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 126/756 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 630/756 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 735/735 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::calculate() |
| [150] | 0.0 | 0.00 | 0.00 | 525 | catMath::formatInput() |
| | | 0.00 | 0.00 | 525/525 | catMath::removeMultSpaces() |
| | | 0.00 | 0.00 | 525/525 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::formatInput() |
| [151] | 0.0 | 0.00 | 0.00 | 525 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::formatInput() |
| [152] | 0.0 | 0.00 | 0.00 | 525 | catMath::removeMultSpaces() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::calculate() |
| [153] | 0.0 | 0.00 | 0.00 | 525 | catMath::parse() |
| | | 0.00 | 0.00 | 17640/19362 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::calculate() |
| [154] | 0.0 | 0.00 | 0.00 | 525 | catMath::postfix() |
| | | 0.00 | 0.00 | 1176/1176 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::calculate() |
| [155] | 0.0 | 0.00 | 0.00 | 525 | catMath::evaluate() |
| | | 0.00 | 0.00 | 1722/19362 | catMath::isOperator() |
| | | 0.00 | 0.00 | 903/903 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/525 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 420/525 | catStddev::readData() |
| [156] | 0.0 | 0.00 | 0.00 | 525 | catMath::calculate() |
| | | 0.00 | 0.00 | 525/525 | catMath::formatInput() |
| | | 0.00 | 0.00 | 525/525 | catMath::parse() |
| | | 0.00 | 0.00 | 525/525 | catMath::postfix() |
| | | 0.00 | 0.00 | 525/525 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 525/525 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 420/420 | catMath::evaluateOperation() |
| [166] | 0.0 | 0.00 | 0.00 | 420 | catMath::evalAdd() |
| | | 0.00 | 0.00 | 420/882 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/315 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 210/315 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 252/252 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/105 | catMath::evaluateOperation() |
| [173] | 0.0 | 0.00 | 0.00 | 105 | catMath::evalNeg() |
| | | 0.00 | 0.00 | 105/882 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/84 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/84 | catMath::evalDiv() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/63 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/63 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [183] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 42/882 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [184] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/882 | catMath::doubleToString() |
| | | 0.00 | 0.00 | 42/64617 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [185] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalSub() |
| | | 0.00 | 0.00 | 21/882 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | _GLOBAL__sub_I__ZN9catStddev4helpEv() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catMath::evaluateOperation() |
| [188] | 0.0 | 0.00 | 0.00 | 21 | catMath::root() |
| | | 0.00 | 0.00 | 12663/64617 | catMath::absVal() |
| | | 0.00 | 0.00 | 8421/8652 | catMath::power() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catStddev::standardDeviation() |
| [190] | 0.0 | 0.00 | 0.00 | 21 | catStddev::readDataFromStdin() |
| | | 0.00 | 0.00 | 21/21 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | main |
| [191] | 0.0 | 0.00 | 0.00 | 21 | catStddev::standardDeviation() |
| | | 0.00 | 0.00 | 105/525 | catMath::calculate() |
| | | 0.00 | 0.00 | 21/21 | catStddev::readDataFromStdin() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catStddev::readDataFromStdin() |
| [192] | 0.0 | 0.00 | 0.00 | 21 | catStddev::readData() |
| | | 0.00 | 0.00 | 420/525 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catMath::evalSub() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
<br>

Tato tabulka popisuje strom volání programu a byla seřazena podle celkového času stráveného v každé funkci a jejích potomcích.

Každý záznam v této tabulce se skládá z několika řádků. Řádek s indexovým číslem na levém okraji uvádí aktuální funkci. Řádky nad ním uvádějí funkce, které tuto funkci volaly, a řádky pod ním uvádějí funkce, které tato funkce volala. Tento řádek uvádí:

- `index`
  - Jedinečné číslo přidělené každému prvku tabulky.
  - Indexová čísla jsou seřazena numericky.
  - Indexové číslo je vytisknuto vedle každého názvu funkce, aby bylo snazší zjistit, kde je funkce v tabulce.
- `time [%]`
  - Toto je procento z *celkového* času, které bylo stráveno v této funkci a jejích potomcích.

  - Vzhledem k různým hlediskům, vyloučenými funkcemi atd. se tyto čísla NESEČTOU na 100%.
- `self`
  - Toto je celkové množství času stráveného v této funkci.
- `children`
  - Toto je celkové množství času, které do této funkce přenesly její potomci.
- `called`
  - Toto je počet volání funkce.
  - Pokud funkce volala sama sebe rekurzivně, číslo zahrnuje pouze nerekurzivní volání a je následováno `+` a počtem rekurzivních volání.
- `name` - Název aktuální funkce.
  - Indexové číslo je vytisknuto za ním.
  - Pokud je funkce členem cyklu, číslo cyklu je vytisknuto mezi názvem funkce a indexovým číslem.

<br>


**Pro rodiče funkce mají pole následující významy:**

- `self`
  - Toto je množství času, které bylo přímo přeneseno z funkce do tohoto rodiče.
- `children`
  - Toto je množství času, které bylo přeneseno z potomků funkce do tohoto rodiče.
- `called`
  - Toto je počet volání, které tento rodič provedl funkci `/` celkový počet volání funkce.
  - Rekurzivní volání funkce nejsou zahrnuta v čísle za `/`.
- `name` - Toto je název rodiče.
  - Indexové číslo rodiče je vytisknuto za ním.
  - Pokud je rodič členem cyklu, číslo cyklu je vytisknuto mezi názvem a indexovým číslem.
- ***Pokud nelze určit rodiče funkce, pole jsou prázdná.***

<br>


**Pro potomky funkce mají pole následující významy:**

- `self`
  - Toto je množství času, které bylo přímo přeneseno z potomka do funkce.
- `children`
  - Toto je množství času, které bylo přeneseno z potomků potomka do funkce.
- `called`
  - Toto je počet volání, které funkce provedla tomuto potomku `/` celkový počet volání potomka.
  - Rekurzivní volání potomkem nejsou uvedena v čísle za `/`.
- `name`
  - Toto je název potomka.
  - Indexové číslo potomka je vytisknuto za ním.
  - Pokud je potomek členem cyklu, číslo cyklu je vytisknuto mezi názvem a indexovým číslem.

<br>


Pokud jsou v grafu volání nějaké cykly (kruhy), existuje záznam pro celý cyklus. Tento záznam ukazuje, kdo volal cyklus (jako rodiče) a členy cyklu (jako potomky). Záznam `+` rekurzivních volání ukazuje počet volání funkcí, které byly interní pro cyklus, a záznam volání pro každého člena ukazuje, kolikrát byl volán od ostatních členů cyklu.

## Indexy funkcí

-    **[9]** ` catMath::absVal()`
-   **[28]** ` catMath::isOperator()`
-   **[55]** ` catMath::power()`
-  **[110]** ` catMath::priority()`
-  **[120]** ` catMath::evaluateOperation()`
-  **[134]** ` catMath::doubleToString()`
-  **[150]** ` catMath::formatInput()`
-  **[151]** ` catMath::pairParenthesis()`
-  **[152]** ` catMath::removeMultSpaces()`
-  **[153]** ` catMath::parse()`
-  **[154]** ` catMath::postfix()`
-  **[155]** ` catMath::evaluate()`
-  **[156]** ` catMath::calculate()`
-  **[166]** ` catMath::evalAdd()`
-  **[173]** ` catMath::evalNeg()`
-  **[183]** ` catMath::evalDiv()`
-  **[184]** ` catMath::evalMul()`
-  **[185]** ` catMath::evalSub()`
-  **[188]** ` catMath::root()`
-  **[190]** ` catStddev::readDataFromStdin()`
-  **[191]** ` catStddev::standardDeviation()`
-  **[192]** ` catStddev::readData()`
