# Zpráva z Gprof
## Informace o systému
**honziksick@CAREN**
- **OS:** Ubuntu 22.04.4 LTS on Windows 10 x86_64
- **Kernel:** 5.15.146.1-microsoft-standard-WSL2
- **Uptime:** 4 hours, 51 mins
- **Packages:** 1983 (dpkg), 10 (snap)
- **Shell:** bash 5.1.16
- **Terminal:** Windows Terminal
- **CPU:** AMD Ryzen 5 2600 (12) @ 3.400GHz
- **GPU:** 6fc0:00:00.0 Microsoft Corporation Device 008e
- **Memory:** 1743MiB / 7921MiB

## Flat profile
### Každý vzorek je počítán jako 0.01 sekundy.
| Time [%] | Cumulative [s] | Self [s] | Calls | Self [ms/call] | Total [ms/call] | Name |
|:---:|:---:|:---:|:---:|:---:|:---:|---|
| 2.79 | 47.52 | 7.28 | 42000105 | 0.00 | 0.00 | catMath::parse() |
| 2.01 | 94.13 | 5.25 | 104995338 | 0.00 | 0.00 | catMath::doubleToString() |
| 1.65 | 107.79 | 4.30 | 42000105 | 0.00 | 0.00 | catMath::evaluate() |
| 1.43 | 131.52 | 3.73 | 42000105 | 0.00 | 0.00 | catMath::postfix() |
| 1.39 | 135.16 | 3.63 | 1673233275 | 0.00 | 0.00 | catMath::isOperator() |
| 1.09 | 143.79 | 2.84 | 104995737 | 0.00 | 0.00 | catMath::evaluateOperation() |
| 0.91 | 156.51 | 2.38 | 42000105 | 0.00 | 0.00 | catMath::removeMultSpaces() |
| 0.77 | 178.25 | 2.01 | 42000105 | 0.00 | 0.00 | catMath::formatInput() |
| 0.59 | 191.92 | 1.54 | 42000105 | 0.00 | 0.00 | catMath::calculate() |
| 0.51 | 203.28 | 1.33 | 209977152 | 0.00 | 0.00 | catMath::priority() |
| 0.46 | 212.07 | 1.20 | 42000105 | 0.00 | 0.00 | catMath::pairParenthesis() |
| 0.41 | 222.09 | 1.06 | 21 | 0.05 | 11.54 | catStddev::readData() |
| 0.26 | 235.40 | 0.69 | 41995569 | 0.00 | 0.00 | catMath::evalNeg() |
| 0.20 | 243.88 | 0.53 | 21002730 | 0.00 | 0.00 | catMath::power() |
| 0.20 | 244.41 | 0.53 | 42000000 | 0.00 | 0.00 | catMath::evalAdd() |
| 0.10 | 251.79 | 0.27 | catMath::associativity() |  |  |  |
| 0.08 | 253.68 | 0.21 | 126020475 | 0.00 | 0.00 | catMath::absVal() |
| 0.00 | 260.84 | 0.01 | catMath::factorial() |  |  |  |
| 0.00 | 260.86 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalDiv() |
| 0.00 | 260.86 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalMul() |
| 0.00 | 260.86 | 0.00 | 42 | 0.00 | 0.00 | catMath::evalSub() |
| 0.00 | 260.86 | 0.00 | 21 | 0.00 | 0.00 | catMath::root() |
| 0.00 | 260.86 | 0.00 | 21 | 0.00 | 11.54 | catStddev::readDataFromStdin() |
| 0.00 | 260.86 | 0.00 | 21 | 0.00 | 11.65 | catStddev::standardDeviation() |


<br>

- `%`:
  - **=** Procento celkové doby běhu programu využité touto funkcí.
- `Cumulative seconds`:
  - **=** Běžný součet sekund přiřazených této funkci a těm, které jsou uvedeny nad ní.
- `Self seconds`:
  - **=** Počet sekund přiřazených pouze této funkci.
  - Toto je hlavní kritérium pro toto seřazení.
- `Calls`:
  - **=** Počet volání této funkce, pokud je tato funkce profilována, jinak prázdné.
- `Self ms/call`:
  - **=** Průměrný počet milisekund strávených v této funkci na volání, pokud je tato funkce profilována, jinak prázdné.
- `Total ms/call`:
  - **=** Průměrný počet milisekund strávených v této funkci a jejích potomcích na volání, pokud je tato funkce profilována, jinak prázdné.
- `Name`:
  - **= Název funkce**
  - Toto je vedlejší kritérium pro toto seřazení.
  - Index ukazuje umístění funkce v seznamu *gprof*.
  - Pokud je index v závorce, ukazuje, kde by se objevil v seznamu *gprof*, pokud by byl vytištěn.

<br>

# Graf volání (call graph)

| Index | Time [%] | Self | Children | Called | Name |
|:-----:|:--------:|:----:|:--------:|:------:|------|
| [1] | 93.8 | 0.00 | 244.68 | | main [1] |
| | | 0.00 | 244.68 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 244.68 | 21/21 | main |
| [2] | 93.8 | 0.00 | 244.68 | 21 | catStddev::standardDeviation() |
| | | 0.00 | 242.36 | 21/21 | catStddev::readDataFromStdin() |
| | | 0.00 | 0.00 | 105/42000105 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 242.36 | 21/21 | catStddev::standardDeviation() |
| [3] | 92.9 | 0.00 | 242.36 | 21 | catStddev::readDataFromStdin() |
| | | 1.06 | 241.30 | 21/21 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 1.06 | 241.30 | 21/21 | catStddev::readDataFromStdin() |
| [4] | 92.9 | 1.06 | 241.30 | 21 | catStddev::readData() |
| | | 1.54 | 237.49 | 42000000/42000105 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/42000105 | catStddev::standardDeviation() |
| | | 1.54 | 237.49 | 42000000/42000105 | catStddev::readData() |
| [5] | 91.6 | 1.54 | 237.49 | 42000105 | catMath::calculate() |
| | | 4.30 | 82.88 | 42000105/42000105 | catMath::evaluate() |
| | | 3.73 | 50.16 | 42000105/42000105 | catMath::postfix() |
| | | 7.28 | 45.29 | 42000105/42000105 | catMath::parse() |
| | | 2.01 | 18.60 | 42000105/42000105 | catMath::formatInput() |
| | | | | | |
| | | | | | |
| | | 4.30 | 82.88 | 42000105/42000105 | catMath::calculate() |
| [6] | 33.4 | 4.30 | 82.88 | 42000105 | catMath::evaluate() |
| | | 2.84 | 16.94 | 104995737/104995737 | catMath::evaluateOperation() |
| | | 0.48 | 0.00 | 220485846/1673233275 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 0.45 | 8.84 | 105000273/892469382 | catMath::parse() |
| | | 1.53 | 30.04 | 356991894/892469382 | catMath::postfix() |
| | | 1.85 | 36.22 | 430477215/892469382 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 3.73 | 50.16 | 42000105/42000105 | catMath::calculate() |
| [9] | 20.7 | 3.73 | 50.16 | 42000105 | catMath::postfix() |
| | | 1.33 | 1.62 | 209977152/209977152 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 7.28 | 45.29 | 42000105/42000105 | catMath::calculate() |
| [10] | 20.2 | 7.28 | 45.29 | 42000105 | catMath::parse() |
| | | 3.16 | 0.00 | 1452747429/1673233275 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 2.01 | 18.60 | 42000105/42000105 | catMath::calculate() |
| [15] | 7.9 | 2.01 | 18.60 | 42000105 | catMath::formatInput() |
| | | 2.38 | 7.25 | 42000105/42000105 | catMath::removeMultSpaces() |
| | | 1.20 | 7.25 | 42000105/42000105 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.76 | 19.30 | 188996031/188996031 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 2.84 | 16.94 | 104995737/104995737 | catMath::evaluate() |
| [18] | 7.6 | 2.84 | 16.94 | 104995737 | catMath::evaluateOperation() |
| | | 0.53 | 3.55 | 42000000/42000000 | catMath::evalAdd() |
| | | 0.69 | 2.97 | 41995569/41995569 | catMath::evalNeg() |
| | | 1.05 | 0.14 | 21000042/104995338 | catMath::doubleToString() |
| | | 0.53 | 0.22 | 21000021/21002730 | catMath::power() |
| | | 0.00 | 0.00 | 21/21 | catMath::root() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 42/42 | catMath::evalSub() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/2729908902 | catStddev::standardDeviation() |
| | | 0.29 | 0.24 | 84000210/2729908902 | catMath::formatInput() |
| | | 0.29 | 0.24 | 84000210/2729908902 | catMath::calculate() |
| | | 0.44 | 0.36 | 125995821/2729908902 | catMath::evaluateOperation() |
| | | 1.63 | 1.35 | 472477320/2729908902 | catMath::evaluate() |
| | | 1.74 | 1.44 | 503973456/2729908902 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.58 | 15.26 | 84000210/84000210 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.58 | 3.75 | 188995947/661473876 | catMath::evaluateOperation() |
| | | 0.87 | 5.63 | 283481898/661473876 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.10 | 0.27 | 42000105/1627445736 | catMath::postfix() |
| | | 0.24 | 0.68 | 104995737/1627445736 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.56 | 11.89 | 104995737/104995737 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.05 | 0.06 | 42000084/4610242035 | catMath::evaluateOperation() |
| | | 0.10 | 0.13 | 83999349/4610242035 | catMath::calculate() |
| | | 1.72 | 2.24 | 1494747534/4610242035 | catMath::parse() |
| | | 1.72 | 2.24 | 1494747534/4610242035 | catMath::removeMultSpaces() |
| | | 1.72 | 2.24 | 1494747534/4610242035 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 2.38 | 7.25 | 42000105/42000105 | catMath::formatInput() |
| [34] | 3.7 | 2.38 | 7.25 | 42000105 | catMath::removeMultSpaces() |
| | | | | | |
| | | | | | |
| | | 0.12 | 0.88 | 42000105/356996367 | catMath::postfix() |
| | | 0.30 | 2.20 | 104995737/356996367 | catMath::evaluate() |
| | | 0.48 | 3.53 | 168000420/356996367 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.08 | 0.27 | 42000105/1007971965 | catMath::postfix() |
| | | 0.21 | 0.68 | 104995737/1007971965 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 1.20 | 7.25 | 42000105/42000105 | catMath::formatInput() |
| [38] | 3.2 | 1.20 | 7.25 | 42000105 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/104995338 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/104995338 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/104995338 | catMath::evalDiv() |
| | | 1.05 | 0.14 | 21000042/104995338 | catMath::evaluateOperation() |
| | | 2.10 | 0.29 | 41995569/104995338 | catMath::evalNeg() |
| | | 2.10 | 0.29 | 41999622/104995338 | catMath::evalAdd() |
| [44] | 2.3 | 5.25 | 0.72 | 104995338 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.03 | 0.00 | 21000042/4463241678 | catMath::evaluateOperation() |
| | | 0.11 | 0.00 | 83999349/4463241678 | catMath::calculate() |
| | | 1.90 | 0.00 | 1452747429/4463241678 | catMath::parse() |
| | | 1.90 | 0.00 | 1452747429/4463241678 | catMath::removeMultSpaces() |
| | | 1.90 | 0.00 | 1452747429/4463241678 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.02 | 0.00 | 21000042/4421241573 | catMath::evaluateOperation() |
| | | 0.04 | 0.00 | 41999244/4421241573 | catMath::calculate() |
| | | 1.38 | 0.00 | 1452747429/4421241573 | catMath::parse() |
| | | 1.38 | 0.00 | 1452747429/4421241573 | catMath::removeMultSpaces() |
| | | 1.38 | 0.00 | 1452747429/4421241573 | catMath::pairParenthesis() |
| | | | | | |
| | | | | | |
| | | 0.53 | 3.55 | 42000000/42000000 | catMath::evaluateOperation() |
| [57] | 1.6 | 0.53 | 3.55 | 42000000 | catMath::evalAdd() |
| | | 2.10 | 0.29 | 41999622/104995338 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.33 | 0.82 | 335996409/1144461003 | catMath::postfix() |
| | | 0.53 | 1.31 | 535472952/1144461003 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.69 | 2.97 | 41995569/41995569 | catMath::evaluateOperation() |
| [62] | 1.4 | 0.69 | 2.97 | 41995569 | catMath::evalNeg() |
| | | 2.10 | 0.29 | 41995569/104995338 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.48 | 0.00 | 220485846/1673233275 | catMath::evaluate() |
| | | 3.16 | 0.00 | 1452747429/1673233275 | catMath::parse() |
| [63] | 1.4 | 3.63 | 0.00 | 1673233275 | catMath::isOperator() |
| | | | | | |
| | | | | | |
| | | 1.33 | 1.62 | 209977152/209977152 | catMath::postfix() |
| [67] | 1.1 | 1.33 | 1.62 | 209977152 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 0.05 | 0.00 | 63000168/3937381875 | catMath::evaluateOperation() |
| | | 0.19 | 0.00 | 251991579/3937381875 | catMath::postfix() |
| | | 0.35 | 0.00 | 472477320/3937381875 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.53 | 0.00 | 293996304/1595943405 | catMath::postfix() |
| | | 0.78 | 0.00 | 430477215/1595943405 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/83995884 | catStddev::standardDeviation() |
| | | 0.65 | 2.02 | 83995674/83995884 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 2.62 | 0.00 | 1410751860/1410752322 | catMath::parse() |
| | | | | | |
| | | | | | |
| | | 0.17 | 2.32 | 42000105/42000105 | catMath::calculate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/167995065 | catMath::evalSub() |
| | | 0.00 | 0.00 | 84/167995065 | catMath::evalMul() |
| | | 0.00 | 0.00 | 84/167995065 | catMath::evalDiv() |
| | | 0.06 | 0.23 | 21000000/167995065 | catStddev::readData() |
| | | 0.06 | 0.23 | 21000042/167995065 | catMath::evaluateOperation() |
| | | 0.11 | 0.47 | 41995569/167995065 | catMath::evalNeg() |
| | | 0.23 | 0.94 | 83999244/167995065 | catMath::evalAdd() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/1711337439 | catMath::evalDiv() |
| | | 0.42 | 0.00 | 335991915/1711337439 | catMath::postfix() |
| | | 1.62 | 0.00 | 1301847897/1711337439 | catMath::priority() |
| | | | | | |
| | | | | | |
| | | 2.08 | 0.00 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.51 | 0.00 | 293996304/892469424 | catMath::postfix() |
| | | 0.74 | 0.00 | 430477215/892469424 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.48 | 0.20 | 146995884/314991789 | catMath::postfix() |
| | | 0.54 | 0.23 | 167995905/314991789 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.05 | 0.20 | 42000105/230996052 | catMath::parse() |
| | | 0.09 | 0.40 | 84000210/230996052 | catMath::postfix() |
| | | 0.12 | 0.50 | 104995737/230996052 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 126/63000126 | catStddev::standardDeviation() |
| | | 0.49 | 0.40 | 63000000/63000126 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.11 | 0.75 | 21000042/21000042 | catMath::evaluateOperation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 2709/21002730 | catMath::root() |
| | | 0.53 | 0.22 | 21000021/21002730 | catMath::evaluateOperation() |
| [126] | 0.3 | 0.53 | 0.22 | 21002730 | catMath::power() |
| | | 0.21 | 0.00 | 126016338/126020475 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.72 | 0.00 | 104995338/104995338 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 252/105000252 | catStddev::standardDeviation() |
| | | 0.48 | 0.18 | 105000000/105000252 | catStddev::readData() |
| | | | | | |
| | | | | | |
| | | 0.06 | 0.43 | 42000105/42000105 | catMath::evaluate() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 105/21000105 | catStddev::standardDeviation() |
| | | 0.38 | 0.04 | 21000000/21000105 | catStddev::readData() |
| | | | | | |
| | | | | | |
| [148] | 0.1 | 0.27 | 0.00 | catMath::associativity() |  |
| | | | | | |
| | | | | | |
| | | 0.17 | 0.09 | 73497585/73497585 | catMath::postfix() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/126020475 | catMath::evalMul() |
| | | 0.00 | 0.00 | 4095/126020475 | catMath::root() |
| | | 0.21 | 0.00 | 126016338/126020475 | catMath::power() |
| [152] | 0.1 | 0.21 | 0.00 | 126020475 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.20 | 0.00 | 21/21 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.01 | 0.04 | 63/63 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/42005460 | catMath::evalMul() |
| | | 0.01 | 0.00 | 42005439/42005460 | catMath::power() |
| | | | | | |
| | | | | | |
| [214] | 0.0 | 0.01 | 0.00 | catMath::factorial() |  |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | catMath::evaluateOperation() |
| [219] | 0.0 | 0.00 | 0.00 | 21 | catMath::root() |
| | | 0.00 | 0.00 | 2709/21002730 | catMath::power() |
| | | 0.00 | 0.00 | 4095/126020475 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/21 | _GLOBAL__sub_I__ZN9catStddev4helpEv() |
| | | | | | |
| | | | | | |
| [221] | 0.0 | 0.00 | 0.00 | _GLOBAL__sub_I__ZN9catStddev4helpEv() | [221] |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [222] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalMul() |
| | | 0.00 | 0.00 | 42/104995338 | catMath::doubleToString() |
| | | 0.00 | 0.00 | 42/126020475 | catMath::absVal() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [223] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 42/104995338 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/42 | catMath::evaluateOperation() |
| [224] | 0.0 | 0.00 | 0.00 | 42 | catMath::evalSub() |
| | | 0.00 | 0.00 | 21/104995338 | catMath::doubleToString() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 21/399 | catMath::evalSub() |
| | | 0.00 | 0.00 | 378/399 | catMath::evalAdd() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 63/63 | catStddev::standardDeviation() |
| | | | | | |
| | | | | | |
| | | 0.00 | 0.00 | 42/840 | catMath::evalSub() |
| | | 0.00 | 0.00 | 42/840 | catMath::evalDiv() |
| | | 0.00 | 0.00 | 756/840 | catMath::evalAdd() |
| | | | | | |
| | | | | | |
<br>

Tato tabulka popisuje strom volání programu a byla seřazena podle celkového času stráveného v každé funkci a jejích potomcích.

Každý záznam v této tabulce se skládá z několika řádků. Řádek s indexovým číslem na levém okraji uvádí aktuální funkci. Řádky nad ním uvádějí funkce, které tuto funkci volaly, a řádky pod ním uvádějí funkce, které tato funkce volala. Tento řádek uvádí:

- `index`
  - Jedinečné číslo přidělené každému prvku tabulky.
  - Indexová čísla jsou seřazena numericky.
  - Indexové číslo je vytisknuto vedle každého názvu funkce, aby bylo snazší zjistit, kde je funkce v tabulce.
- `time [%]`
  - Toto je procento z *celkového* času, které bylo stráveno v této funkci a jejích potomcích.

  - Vzhledem k různým hlediskům, vyloučenými funkcemi atd. se tyto čísla NESEČTOU na 100%.
- `self`
  - Toto je celkové množství času stráveného v této funkci.
- `children`
  - Toto je celkové množství času, které do této funkce přenesly její potomci.
- `called`
  - Toto je počet volání funkce.
  - Pokud funkce volala sama sebe rekurzivně, číslo zahrnuje pouze nerekurzivní volání a je následováno `+` a počtem rekurzivních volání.
- `name` - Název aktuální funkce.
  - Indexové číslo je vytisknuto za ním.
  - Pokud je funkce členem cyklu, číslo cyklu je vytisknuto mezi názvem funkce a indexovým číslem.

<br>


**Pro rodiče funkce mají pole následující významy:**

- `self`
  - Toto je množství času, které bylo přímo přeneseno z funkce do tohoto rodiče.
- `children`
  - Toto je množství času, které bylo přeneseno z potomků funkce do tohoto rodiče.
- `called`
  - Toto je počet volání, které tento rodič provedl funkci `/` celkový počet volání funkce.
  - Rekurzivní volání funkce nejsou zahrnuta v čísle za `/`.
- `name` - Toto je název rodiče.
  - Indexové číslo rodiče je vytisknuto za ním.
  - Pokud je rodič členem cyklu, číslo cyklu je vytisknuto mezi názvem a indexovým číslem.
- ***Pokud nelze určit rodiče funkce, pole jsou prázdná.***

<br>


**Pro potomky funkce mají pole následující významy:**

- `self`
  - Toto je množství času, které bylo přímo přeneseno z potomka do funkce.
- `children`
  - Toto je množství času, které bylo přeneseno z potomků potomka do funkce.
- `called`
  - Toto je počet volání, které funkce provedla tomuto potomku `/` celkový počet volání potomka.
  - Rekurzivní volání potomkem nejsou uvedena v čísle za `/`.
- `name`
  - Toto je název potomka.
  - Indexové číslo potomka je vytisknuto za ním.
  - Pokud je potomek členem cyklu, číslo cyklu je vytisknuto mezi názvem a indexovým číslem.

<br>


Pokud jsou v grafu volání nějaké cykly (kruhy), existuje záznam pro celý cyklus. Tento záznam ukazuje, kdo volal cyklus (jako rodiče) a členy cyklu (jako potomky). Záznam `+` rekurzivních volání ukazuje počet volání funkcí, které byly interní pro cyklus, a záznam volání pro každého člena ukazuje, kolikrát byl volán od ostatních členů cyklu.

## Indexy funkcí

-    **[2]** ` catStddev::standardDeviation()`
-    **[3]** ` catStddev::readDataFromStdin()`
-    **[4]** ` catStddev::readData()`
-    **[5]** ` catMath::calculate()`
-    **[6]** ` catMath::evaluate()`
-    **[9]** ` catMath::postfix()`
-   **[10]** ` catMath::parse()`
-   **[15]** ` catMath::formatInput()`
-   **[18]** ` catMath::evaluateOperation()`
-   **[34]** ` catMath::removeMultSpaces()`
-   **[38]** ` catMath::pairParenthesis()`
-   **[44]** ` catMath::doubleToString()`
-   **[57]** ` catMath::evalAdd()`
-   **[62]** ` catMath::evalNeg()`
-   **[63]** ` catMath::isOperator()`
-   **[67]** ` catMath::priority()`
-  **[126]** ` catMath::power()`
-  **[148]** ` catMath::associativity()`
-  **[152]** ` catMath::absVal()`
-  **[214]** ` catMath::factorial()`
-  **[219]** ` catMath::root()`
-  **[222]** ` catMath::evalMul()`
-  **[223]** ` catMath::evalDiv()`
-  **[224]** ` catMath::evalSub()`
